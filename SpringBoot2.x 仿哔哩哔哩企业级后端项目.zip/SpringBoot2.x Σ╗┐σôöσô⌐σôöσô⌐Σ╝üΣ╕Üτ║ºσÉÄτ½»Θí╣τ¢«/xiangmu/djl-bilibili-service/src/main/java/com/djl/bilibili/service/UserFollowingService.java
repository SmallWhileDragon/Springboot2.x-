package com.djl.bilibili.service;

import com.djl.bilibili.dao.UserFollowingDao;
import com.djl.bilibili.domain.FollowingGroup;
import com.djl.bilibili.domain.User;
import com.djl.bilibili.domain.UserFollowing;
import com.djl.bilibili.domain.UserInfo;
import com.djl.bilibili.domain.constant.UserConstant;
import com.djl.bilibili.domain.exception.ConditionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserFollowingService {
    @Autowired
    private UserFollowingDao userFollowingDao;
    @Autowired
    private FollowingGroupService followGroupService;
    @Autowired
    private UserService userService;
    @Transactional
    public void addUserFollowing(UserFollowing userFollowing) {
        //第一：首先根据userFollowing.getGroupId 获取groupId初步判断关注用户分组是否为空
        //如果为空首先将通过followGroupService逻辑设置一个默认分组，然后赋予给userFollowing
        //如果不为空再通过该followGroupService.getById(groupId),验证分组是否存在
        Long groupId = userFollowing.getGroupId();
        if (groupId == null) {
            //因为在followGroupService中已经默认添加了三个分组type,在Dao模块配置默认分组常量
            FollowingGroup followingGroup = followGroupService.getByType(UserConstant.USER_FOLLOWING_GROUP_TYPE_DEFAULT);
            userFollowing.setGroupId(followingGroup.getId());
        } else {
            FollowingGroup followingGroup = followGroupService.getById(groupId);
            if (followingGroup == null) {
                throw new ConditionException("关注分组不存在！");
            }
        }
        //第二：查看关注的人是否存在通过userFollowing.getFollowingId()获取到followingId，
        //然后通过用户服务逻辑也就是在整个用户数据库查询followingId，验证关注人是否存在userService.getUserById(followingId)
        //不存在的话就抛出异常，存在的话，就删除关联关系，再新增的这样一种添加方式
            Long followingId = userFollowing.getFollowingId();
            User user = userService.getUserById(followingId);
            if (user == null) {
                throw new ConditionException("关注的用户不存在!");
            }
            //先删除关联关系，再新增
            userFollowingDao.deleteUserFollowing(userFollowing.getUserId(), followingId);
            userFollowing.setCreateTime(new Date());
            userFollowingDao.addUserFollowing(userFollowing);
        }
        //获取用户关注列表
//        第一步：获取关注的用户列表，可以通过userFollowingDao.getUserFollowings(userId)
    //使用java8的lambda表达式，stream流操作 list.stream().map(UserFollowing::getFollowingId).collect(Collectors.toSet())获取到所有关注的用户的id
    // 第二步：利用所有关注用户的id，再通过整个用户数据库查找到他们对应的个人信息userService.getUserInfoByUserIds(followingIdSet)
//我们事前再（用户关注）UserFollowing这个实体类中写上用户个人信息userInfo属性这个冗余字段
    //然后可以通过两个双重增强for循环分别取出每个关注人id，以及之前查询到的关注人的个人信息id进行循环比较，如果相等，那么就讲该id对应的userInfo作为属性通过set
    //赋值到对应的userFollowing
//        第三步：将关注用户按关注分组进行分类
        public List<FollowingGroup> getUserFollowings(Long userId){
         List<UserFollowing> list = userFollowingDao.getUserFollowings(userId);
//         使用java8的lambda表达式，stream流操作获取followingIdSet一个set集合
           Set<Long> followingIdSet = list.stream().map(UserFollowing::getFollowingId).collect(Collectors.toSet());
           List<UserInfo> userInfoList = new ArrayList<>();
           //写一个userService.getUserInfoByUserIds(followingIdSet)根据关注人的id集合找到他们对应的个人信息
           if(followingIdSet.size()>0){
               userInfoList = userService.getUserInfoByUserIds(followingIdSet);
           }
           //获取关注的用户列表
           for(UserFollowing userFollowing:list){
               //根据关注用户的Id查询关注用户的基本信息
               for(UserInfo userInfo : userInfoList){
                   //获取关注的用户列表中的每一个和userInfoList集合进行比较他们的id是否相等
                   if(userFollowing.getFollowingId().equals(userInfo.getUserId())){
                       //在userFollowing实体类中加入userInfo类作为属性
                       userFollowing.setUserInfo(userInfo);
                   }
               }
           }
           //通过followGroupService.getByUserId(userId)查询到用户的全部分组
           List<FollowingGroup> groupList = followGroupService.getByUserId(userId);
           FollowingGroup allGroup = new FollowingGroup();
           allGroup.setName(UserConstant.USER_FOLLOWING_GROUP_ALL_NAME);
           //在FollowingGroup实体类中在加入一个List<userInfo>集合属性
           allGroup.setFollowingUserInfoList(userInfoList);
           //最后写一个返回的数据
           List<FollowingGroup> result = new ArrayList<>();
           //result集合先添加全部分组中的全部关注人员
           result.add(allGroup);
           //从groupList取出某一个分组
           for(FollowingGroup group : groupList){
               //在循环到每一个分组的时候就建立一个List<UserInfo>
               List<UserInfo> infoList = new ArrayList<>();
               //循环全部关注的人
               for(UserFollowing userFollowing :list){
                   //比较分组的group.getId和userFollowing.getGroupId()的大小
                      if(group.getId().equals(userFollowing.getGroupId())){
                          //如果一致进行关注用户的添加
                          infoList.add(userFollowing.getUserInfo());
                      }
               }
               //将一个分组加入到结果中
               group.setFollowingUserInfoList(infoList);
               //将这个分组再加入result中
               result.add(group);
           }
           return result;
        }
        //  第一步：获取当前用户的粉丝列表
//          第二步：根据粉丝的用户id查询基本信息
//          第三步：查询当前用户是否已经关注该粉丝
    public List<UserFollowing> getUserFans(Long userId){
       List<UserFollowing> fanList =  userFollowingDao.getUserFans(userId);
        Set<Long> fanIdSet = fanList.stream().map(UserFollowing::getUserId).collect(Collectors.toSet());
        List<UserInfo> userInfoList = new ArrayList<>();
        if(fanIdSet.size()>0){
            userInfoList = userService.getUserInfoByUserIds(fanIdSet);
        }
        List<UserFollowing>  followingList = userFollowingDao.getUserFollowings(userId);
        for(UserFollowing fan :  fanList){
            for(UserInfo userInfo : userInfoList){
                if(fan.getUserId().equals(userInfo.getUserId())){
                    userInfo.setFollowed(false);
                    fan.setUserInfo(userInfo);
                }
            }
            for(UserFollowing following: followingList){
                if(following.getFollowingId().equals(fan.getUserId())){
                    fan.getUserInfo().setFollowed(true);
                }
            }
        }
        return fanList;
    }
//增加用户关注分组
    public Long addUserFollowingGroup(FollowingGroup followingGroup) {
        followingGroup.setCreatTime(new Date());
        followingGroup.setType(UserConstant.USER_FOLLOWING_GROUP_TYPE_USER);
        followGroupService.addFollowingGroup(followingGroup);
        return followingGroup.getId();
    }
//获取用户分组
    public List<FollowingGroup> getUserFollowingsGroups(Long userId) {
        return followGroupService.getUserFollowingGroup(userId);
    }

    public List<UserInfo> checkFollowingStatus(List<UserInfo> userInfoList, Long userId) {
        List<UserFollowing> userFollowingList = userFollowingDao.getUserFollowings(userId);
        for(UserInfo userInfo : userInfoList){
            userInfo.setFollowed(false);
            for(UserFollowing userFollowing : userFollowingList){
                if(userFollowing.getUserId().equals(userInfo.getUserId())){
                   userInfo.setFollowed(true);
                }
            }
        }
        return userInfoList;
    }
}

