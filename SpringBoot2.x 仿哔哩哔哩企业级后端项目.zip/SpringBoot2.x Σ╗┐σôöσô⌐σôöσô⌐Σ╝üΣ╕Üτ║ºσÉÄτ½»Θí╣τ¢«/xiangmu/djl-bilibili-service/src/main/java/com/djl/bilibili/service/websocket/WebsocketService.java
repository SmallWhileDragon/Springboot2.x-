package com.djl.bilibili.service.websocket;

import com.alibaba.fastjson.JSONObject;
import com.djl.bilibili.domain.Danmu;
import com.djl.bilibili.domain.constant.UserMomentsConstant;
import com.djl.bilibili.service.DanmuService;
import com.djl.bilibili.service.util.RocketMQUtil;
import com.djl.bilibili.service.util.TokenUtil;
import io.netty.util.internal.StringUtil;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.common.message.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Component
//@ServerEndpoint("/imserver/{token}")标注连接点，并且配置路径
@ServerEndpoint("/imserver/{token}")
public class WebsocketService {
    //进行日志记录
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    //在线人数统计
    private static  final AtomicInteger ONLINE_COUNT = new AtomicInteger(0);
    //存放所有客户端关联的websocketService
    public static final ConcurrentHashMap<String,WebsocketService> WEBSOCKET_MAP = new ConcurrentHashMap<>();
    //服务端和客户端进行长连接通信的
    private Session session;
    //根据session的Id进行唯一标识
    private String sessionId;
    private Long userId;
    //建立一个全局上下文公用的ApplicationContext
    private static ApplicationContext APPLICATION_CONTEXT;
    public static void setApplicationContext(ApplicationContext applicationContext){
        WebsocketService.APPLICATION_CONTEXT = applicationContext;
    }
//打开连接通信
    @OnOpen
    public void openConnection(Session session, @PathParam("token") String token){
        try {
            this.userId = TokenUtil.verifyToken(token);
            
        }catch (Exception e){}
      this.sessionId = session.getId();
      this.session = session;
      //进行判断WebsocketService是否已经连接
      if(WEBSOCKET_MAP.containsKey(sessionId)){
          WEBSOCKET_MAP.remove(sessionId);
          WEBSOCKET_MAP.put(sessionId,this);
      }else {
          WEBSOCKET_MAP.put(sessionId,this);
          //在线人数加一
          ONLINE_COUNT.getAndIncrement();
      }
      logger.info("用户连接成功" + sessionId + ",当前在线人数为：" + ONLINE_COUNT.get());
      try {
          //当连接成功以后，需要告知前端我们已经连接成功，方便进行其他操作，通过sendMessage这个方法
           this.sendMessage("0");
      }catch (Exception e){
          logger.error("连接异常");
      }
    }
    //关闭连接通信
    @OnClose
    public void closeConnection(){
        if(WEBSOCKET_MAP.containsKey(sessionId)){
            //移除WebsocketService，并且在线用户减一
            WEBSOCKET_MAP.remove(sessionId);
            ONLINE_COUNT.getAndDecrement();
        }
        logger.info("用户退出" + sessionId + "当前在线人数为：" + ONLINE_COUNT.get());
    }
    //当有消息通信的时候
    @OnMessage
    public void onMessage(String message){
       logger.info("用户信息: " + sessionId + ", 报文： " + message);
       if(!StringUtil.isNullOrEmpty(message)){
           try {
                   //群发消息需要用到并发➕队列
                  //首先我们用增强for循环将每个websocketService拿出来
               // 可以使用Map.Entry<String,WebsocketService> entry : WEBSOCKET_MAP.entrySet()
                   for(Map.Entry<String,WebsocketService> entry : WEBSOCKET_MAP.entrySet()){
                       //由entry.getValue()获取每个websocketService
                       WebsocketService websocketService = entry.getValue();
                       //由于每个websocketService用到是多例模式，所以在使用MQ队列时，需要用到APPLICATION_CONTEXT进行bean获取
                       //DefaultMQProducer  danmusProducer = (DefaultMQProducer) APPLICATION_CONTEXT.getBean("danmusProducer");
                       DefaultMQProducer  danmusProducer = (DefaultMQProducer) APPLICATION_CONTEXT.getBean("danmusProducer");
                       //使用jsonObject类进行消息的构建，jsonObject底层是一个map类型
                       //所以message作为键，websocketService.getSessionId()作为值
                       JSONObject jsonObject = new JSONObject();
                       jsonObject.put("message",message);
                       jsonObject.put("sessionId" , websocketService.getSessionId());
                       //将消息队列的Message（参数一分组，参数二需要传送的消息我们先用jsonObject.toJSONString().getBytes(StandardCharsets.UTF_8)转换为一个byte数组）
                       //然后使用异步发送消息到生产者
                       Message msg = new Message(UserMomentsConstant.TOPIC_DANMUS,jsonObject.toJSONString().getBytes(StandardCharsets.UTF_8));
                       RocketMQUtil.asyncSendMsg(danmusProducer,msg);
                   }
                   if(this.userId!=null){
                       //保存弹幕到数据库，用到异步保存
                       Danmu danmu = JSONObject.parseObject(message,Danmu.class);
                       danmu.setUserId(userId);
                       danmu.setCreateTime(new Date());
                       DanmuService danmuService = (DanmuService) APPLICATION_CONTEXT.getBean("danmuService");
                       danmuService.asyncAddDanmu(danmu);
                       //保存弹幕到redis，同步保存
                       danmuService.addDanmusToRedis(danmu);
                   }

           }catch (Exception e){
               logger.error("弹幕接收出现问题");
               e.printStackTrace();
           }
        }
    }

    @OnError
    public void onError(Throwable error){

    }
    public void sendMessage(String message) throws IOException {
        this.session.getBasicRemote().sendText(message);
    }
    //或直接指定时间间隔，列如：5秒
    @Scheduled(fixedRate = 5000)
    private void noticeOnlineCount() throws IOException{
        for(Map.Entry<String,WebsocketService> entry: WebsocketService.WEBSOCKET_MAP.entrySet()){
            WebsocketService websocketService = entry.getValue();
            if(websocketService.session.isOpen()){
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("onlineCount",ONLINE_COUNT.get());
                jsonObject.put("msg","当前在线人数为" + ONLINE_COUNT.get());
                websocketService.sendMessage(jsonObject.toJSONString());
            }
        }
    }
    public Session getSession() {return session;}
    public String getSessionId(){
        return sessionId;
    }
}
