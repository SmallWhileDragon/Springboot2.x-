package com.djl.bilibili.service.util;

import com.djl.bilibili.domain.exception.ConditionException;
import com.github.tobato.fastdfs.domain.fdfs.FileInfo;
import com.github.tobato.fastdfs.domain.fdfs.MetaData;
import com.github.tobato.fastdfs.domain.fdfs.StorePath;
import com.github.tobato.fastdfs.domain.proto.storage.DownloadCallback;
import com.github.tobato.fastdfs.service.AppendFileStorageClient;
import com.github.tobato.fastdfs.service.FastFileStorageClient;
import io.netty.util.internal.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

@Component
public class FastDFSUtil {
    //主要针对中小文件的上传操作
    @Autowired
    private FastFileStorageClient fastFileStorageClient;
    //主要实现对大文件的相关操作，比如断点上传
    @Autowired
    private AppendFileStorageClient appendFileStorageClient;
    @Autowired
    private RedisTemplate<String,String> redisTemplate;
    private static final String DEFAULT_GROUP = "group1";
    private static final String PATH_KEY = "path-key:";
    private static final String UPLOADED_SIZE_KEY = "uploaded-size-key:";
    private static final String UPLOADED_No_KEY = "uploaded-no-key:";
    private static final int SLICE_SIZE = 1024*1024*2;
    @Value("${fdfs.http.storage-addr}")
    private String httpFdfsStorageAddr;
    //获取文件类型
    public String getFileType(MultipartFile file){
        //对文件进行判断file是否为空null
           if(file==null){
               throw new ConditionException("非法文件！");
           }
           //通过file.getOriginalFilename获取String fileName
           String fileName = file.getOriginalFilename();
           //对文件名进行截取，取得属于格式的那一部分，1.index = fileName.lastIndexOf("."),
           //2. fileName.substring(index+1,fileName.length())
           int index = fileName.lastIndexOf(".");
           return fileName.substring(index+1,fileName.length());
    }
    //上传普通类型的文件
    public String uploadCommonFile(MultipartFile file)throws Exception{
//        首先构建文件fastFileStorageClient参数类型，Set<MetaData> metaDataSet元数据类型
        Set<MetaData> metaDataSet = new HashSet<>();
//        文件格式类型（可以写成一个通用的获取文件格式的通用方法），以及文件的大小file.getSize()
        String fileType = this.getFileType(file);
        //最后通过storePath =fastFileStorageClient.uploadFile(file.getInputStream(),file.getSize(),fileType,metaDataSet)
        //返回路径storePath.getPath()
       StorePath storePath =  fastFileStorageClient.uploadFile(file.getInputStream(),file.getSize(),fileType,metaDataSet);
       return  storePath.getPath();
    }
    public String uploadCommonFile(File file,String fileType)throws Exception{
        Set<MetaData> metaDataSet = new HashSet<>();
        StorePath storePath = fastFileStorageClient.uploadFile(new FileInputStream(file),file.length(),fileType,metaDataSet);
        return storePath.getPath();
    }
    //上传可以断点续传的文件
    public String uploadAppenderFile(MultipartFile file)throws Exception{
        String fileName = file.getOriginalFilename();
        //获取文件格式类型
        String fileType = this.getFileType(file);
        //获取storePath = appendFileStorageClient.uploadAppenderFile(DEFAULT_GROUP,file.getInputStream(),file.getSize(),fileType)
        StorePath storePath = appendFileStorageClient.uploadAppenderFile(DEFAULT_GROUP,file.getInputStream(),file.getSize(),fileType);
        return storePath.getPath();
    }
    //对断点文件的添加，long offset可以理解为实际需要添加的位置
    public void modifyAppenderFile(MultipartFile file,String filePath,long offset)throws Exception{
              appendFileStorageClient.modifyFile(DEFAULT_GROUP,filePath,file.getInputStream(),file.getSize(),offset);
    }
//    FastDFSUtil进行对文件进行分片上传
    public String uploadFileBySlices(MultipartFile file, String fileMd5,Integer sliceNo, Integer totalSliceNo)throws Exception{
        //输入参数的判断file/sliceNo/totalSliceNo的非空判断异常判断
        if(file == null||sliceNo==null||totalSliceNo==null){
           throw new ConditionException("参数异常");
        }
//      生成三个关于redis的参数，分片的存储路径暂时先存储在redis中，等所有的分片全部上传之后再清空这些信息
        String pathKey = PATH_KEY + fileMd5;
        //uploadedSizeKey是指所有分片加起来的总大小，因为appendFileStorageClient.modifyFile中的一个参数offset主要就是根据uploadedSizeKey大小确定的
        String uploadedSizeKey = UPLOADED_SIZE_KEY + fileMd5;
        //uploadedNoKey是指目前已经上传多少分片了
        String uploadedNoKey = UPLOADED_No_KEY + fileMd5;
        String uploadedSizeStr = redisTemplate.opsForValue().get(uploadedSizeKey);
        Long uploadedSize = 0L;
        //对!StringUtil.isNullOrEmpty(uploadedSizeStr)进行判断
        if(!StringUtil.isNullOrEmpty(uploadedSizeStr)){
//         获取这个uploadedSize的原因就是要考虑获的这个分片是第一个分片，还是除了第一个分片之外的其他分片
            uploadedSize=Long.valueOf(uploadedSizeStr);
        }
        //获取文件格式类型
        String fileType = this.getFileType(file);
        //判断上传的是否是第一个分片
        if(sliceNo==1){
            String path =  this.uploadAppenderFile(file);
            if(StringUtil.isNullOrEmpty(path)){
                throw  new ConditionException("上传失败");
            }
//            然后吧文件路径先储存到redisTemplate中
            redisTemplate.opsForValue().set(pathKey,path);
//            吧文件的大小储存到redisTemplate中
            uploadedSize += file.getSize();
            redisTemplate.opsForValue().set(uploadedSizeKey,String.valueOf(uploadedSize));
//            吧文件的序号储存到redisTemplate中
            redisTemplate.opsForValue().set(uploadedNoKey,"1");
        }else {
//            当判断上传的分片不是第一个时
            String filePath = redisTemplate.opsForValue().get(pathKey);
            if(StringUtil.isNullOrEmpty(filePath)){
                throw new ConditionException("上传失败");
            }
            this.modifyAppenderFile(file,filePath,uploadedSize);
//            更新redisTemplate的参数
            redisTemplate.opsForValue().increment(uploadedNoKey);
        }
        //修改历史上传文件大小
        uploadedSize+=file.getSize();
        //用String.valueOf(uploadedSize)可以避免空指针异常
        redisTemplate.opsForValue().set(uploadedSizeKey,String.valueOf(uploadedSize));
//       如果所有分片全部上传完毕 判断当前上传的文件序号是否和总的文件序号一致,如何一致，就可以吧redisTemplate相关的key全部删掉,然后返回前端一个
//        上传好的文件路径
        String uploadedNoStr = redisTemplate.opsForValue().get(uploadedNoKey);
        Integer uploadedNo =  Integer.valueOf(uploadedNoStr);
        String resultPath = "";
        //判断totalSliceNo和uploadedNo大小是否相等
        if(uploadedNo.equals(totalSliceNo)){
            //将resultPath在删除redis键之前保存下来，返回
            resultPath = redisTemplate.opsForValue().get(pathKey);
//              如果相同，HttpUtil.java
            List<String> keyList = Arrays.asList(uploadedNoKey,pathKey,uploadedSizeKey);
            redisTemplate.delete(keyList);
        }
//        吧文件路径返回给前段
        return resultPath;
    }
//    分片操作
    public void convertFileToSlices(MultipartFile multipartFile)throws Exception{
        String fileName = multipartFile.getOriginalFilename();
        //通过传入multipartFile文件，通过之前写的方法获取文件的filetype，并将multipartFile通过multipartFileToFile转化为file
        String filetype = this.getFileType(multipartFile);
        File file = this.multipartFileToFile(multipartFile);
        long fileLength = file.length();
        int count = 1;
        for(int i = 0; i<fileLength; i+=SLICE_SIZE){
//            RandomAccessFile是java提供一个对文件的处理工具,可以跳到文件任意的地方来读写数据
            RandomAccessFile randomAccessFile = new RandomAccessFile(file,"r");
            //搜寻到想到开始的位置，所以写一个for循环，通过randomAccessFile.seek(i)读取到指定位置，
            //用byte数组定义分片容量
            //然后通过 randomAccessFile.read(bytes)进行读操作，同时定义输出流进行写操作，这样就将文件进行分片
            //注意记录分片后的储存路径
            randomAccessFile.seek(i);
            byte[] bytes = new byte[SLICE_SIZE];
            int len = randomAccessFile.read(bytes);
            String path = "/Users/dr.ding/Desktop/wenjian/"+count+"."+filetype;
            File slice  = new File(path);
            FileOutputStream fos = new FileOutputStream(slice);
            fos.write(bytes,0,len);
            fos.close();
            count++;
        }
        file.delete();
    }
//    转化为文件的方法
    public File multipartFileToFile(MultipartFile multipartFile)throws Exception{
        String originalFileName = multipartFile.getOriginalFilename();
        String[] fileName = originalFileName.split("\\.");
        File file = File.createTempFile(fileName[0],"."+fileName[1]);
        multipartFile.transferTo(file);
        return file;
    }
    //删除
    public void deleteFile(String filePath){
        fastFileStorageClient.deleteFile(filePath);
    }
    public void viewVideoOnlineBySlice(HttpServletRequest request, HttpServletResponse response, String path)throws Exception {
        //通过FastDfs提供的api fastFileStorageClient.queryFileInfo(DEFAULT_GROUP,path)进行获取文件信息
        FileInfo fileInfo =  fastFileStorageClient.queryFileInfo(DEFAULT_GROUP,path);
        //获取文件总大小
        long totalFileSize = fileInfo.getFileSize();
        //通过拼接httpFdfsStorageAddr + path获取文件的路径url
        String url = httpFdfsStorageAddr + path;
        //通过request.getHeaderNames()获取所有请求头的信息，返回类型是枚举类型
        Enumeration<String> headerNames =  request.getHeaderNames();
        Map<String,Object> headers = new HashMap<>();
        //通过一个while循环headerNames.hasMoreElements()判断当前枚举类型里面还有没有更多的数据
        //然后取出头节点的每个信息放入自定义的map类型headers中
        while (headerNames.hasMoreElements()){
            String header = headerNames.nextElement();
            headers.put(header,request.getHeader(header));
        }
//        获取文件的字节范围
        String rangeStr = request.getHeader("Range");
        String[] range;
        //对rangeStr进行数据大小判断，如果为空rangeStr = "bytes=0-"+(totalFileSize-1)，
        //如果不为空通过 range = rangeStr.split("bytes=|-");拆成几个部分
        if(StringUtil.isNullOrEmpty(rangeStr)){
            rangeStr = "bytes=0-"+(totalFileSize-1);
        }
        range = rangeStr.split("bytes=|-");
        long begin = 0;
        //然后对range的长度进行判断，再写相关逻辑
        if(range.length>=2){
            begin = Long.parseLong(range[1]);
        }
        long end = totalFileSize-1;
        if(range.length>=3){
            end = Long.parseLong(range[2]);
        }
        //判断视频长度len = end-begin+1
        long len = (end-begin) +1;
        //对请求头信息contentRange进行赋值
        String contentRange = "bytes" + begin + "-" + end + "/" + totalFileSize;
        //将请求头的值重新通过setHeader赋值
        response.setHeader("Content-Range",contentRange);
        response.setHeader("Accept-Ranges","bytes");
        response.setHeader("Content-Type","video/map4");
        response.setContentLength((int)len);
        response.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT);
        //最后调用HttpUtil.get(url,headers,response)进一步处理
        HttpUtil.get(url,headers,response);
    }

    public void downLoadFile(String url, String localPath) {
        fastFileStorageClient.downloadFile(DEFAULT_GROUP, url, new DownloadCallback<String>() {
            @Override
            public String recv(InputStream ins) throws IOException{
                File file = new File(localPath);
                OutputStream os = new FileOutputStream(file);
                int len = 0;
                byte[] buffer = new byte[1024];
                while ((len = ins.read(buffer))!=-1){
                    os.write(buffer,0,len);
                }
                os.close();
                ins.close();
                return "success";
            }
        });
    }
}
