package com.djl.bilibili.service;

import com.djl.bilibili.dao.FileDao;
import com.djl.bilibili.service.util.FastDFSUtil;
import com.djl.bilibili.service.util.MD5Util;
import io.netty.util.internal.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.djl.bilibili.domain.File;

import java.util.Date;


@Service
public class FileService {
      @Autowired
       private FileDao fileDao;
       @Autowired
       private FastDFSUtil fastDFSUtil;
    public String uploadFileBySlices(MultipartFile slice, String fileMd5, Integer sliceNo, Integer totalSliceNo) throws Exception{
//    //先查找数据库中是否存在相同文件，如果有直接返回该文件路径，相当于实现秒传功能
        File dbFileMD5 = fileDao.getFileByMD5(fileMd5);
        if (dbFileMD5 != null) {
            return dbFileMD5.getUrl();
        }
        //如果没有就使用fastDFSUtil.uploadFileBySlices(slice,fileMd5,sliceNo,totalSliceNo)，之前在fastDFSUtil写的方法
        String url = fastDFSUtil.uploadFileBySlices(slice,fileMd5,sliceNo,totalSliceNo);
        //然后将该文件的信息储存到dbFileMD5文件中setCreateTime，setMd5，setUrl，setType
        if(!StringUtil.isNullOrEmpty(url)){
            dbFileMD5 = new File();
            dbFileMD5.setCreateTime(new Date());
            dbFileMD5.setMd5(fileMd5);
            dbFileMD5.setUrl(url);
            dbFileMD5.setType(fastDFSUtil.getFileType(slice));
            //添加该dbFileMD5文件到数据库中
            fileDao.addFile(dbFileMD5);
        }
       return url;
    }

    public String getFileMD5(MultipartFile file) throws Exception {
        return MD5Util.getFileMD5(file);
    }

    public File getFileByMd5(String fileMd5) {
        return fileDao.getFileByMD5(fileMd5);
    }
}
