package com.djl.bilibili.service;

import com.djl.bilibili.dao.Demodao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DemoService {
    @Autowired
    private Demodao demodao;
    public Long query(Long id){
        return demodao.query(id);
    }
}
