package com.djl.bilibili.service.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.djl.bilibili.domain.exception.ConditionException;
import com.mysql.cj.exceptions.DataReadException;

import javax.xml.crypto.Data;
import java.util.Calendar;
import java.util.Date;

import static java.util.Calendar.*;

public class TokenUtil {
    //写成一个static方法可以直接被调用
    private static final String ISSUER="签发者";
    //创建token
    public static String generateToken(Long userId) throws Exception{
        //使用依赖jwt包下的Algorithm并且用RSA256进行加密，使用之间在RSAUtil获得的公钥和私钥
        Algorithm algorithm = Algorithm.RSA256(RSAUtil.getPublicKey(),RSAUtil.getPrivateKey());
        //创建时间类，主要为了后续生成过期时间的
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        //设置过期时间
        calendar.add(Calendar.HOUR,1);
        //设置JWT载荷新秀，String.valueOf(userId))（唯一身份标识），withIssuer（签发者），withExpiresAt（过期时间）
        //再调用sign方法进行获取签名，进行加密
        return JWT.create().withKeyId(String.valueOf(userId)).withIssuer(ISSUER)
                .withExpiresAt(calendar.getTime())
                .sign(algorithm);
    }
    //刷新token
    public static String generatRefreshToken(Long userId) throws Exception{
        Algorithm algorithm = Algorithm.RSA256(RSAUtil.getPublicKey(),RSAUtil.getPrivateKey());
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(DAY_OF_MONTH,7);
        return JWT.create().withKeyId(String.valueOf(userId)).withIssuer(ISSUER)
                .withExpiresAt(calendar.getTime())
                .sign(algorithm);
    }
    //验证token
    public static Long verifyToken(String token){
        try {
            //进行一个RSA解密
            Algorithm algorithm = Algorithm.RSA256(RSAUtil.getPublicKey(),RSAUtil.getPrivateKey());
            //使用依赖jwt包下的JWT调用require方法生成验证的类
            JWTVerifier verifier = JWT.require(algorithm).build();
            //使用验证类对JWT的创建的token进行验证
            DecodedJWT jwt = verifier.verify(token);
            String userId = jwt.getKeyId();
            return Long.valueOf(userId);
        } catch (TokenExpiredException e) {
            throw new ConditionException("555","token过期！");
        }catch (Exception e){
            throw  new ConditionException("非法用户token!");
        }
    }
}
