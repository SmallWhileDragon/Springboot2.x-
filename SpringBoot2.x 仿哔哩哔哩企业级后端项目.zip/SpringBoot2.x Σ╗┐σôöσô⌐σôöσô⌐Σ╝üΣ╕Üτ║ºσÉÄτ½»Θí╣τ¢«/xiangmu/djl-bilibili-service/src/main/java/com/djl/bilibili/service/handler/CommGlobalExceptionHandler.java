package com.djl.bilibili.service.handler;

import com.djl.bilibili.domain.JsonResponse;
import com.djl.bilibili.domain.exception.ConditionException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CommGlobalExceptionHandler {
  @ExceptionHandler(value = Exception.class)
//  这个注解标识我返回的这个参数是RequestBody
    @ResponseBody
  //HttpServletRequest封装从前端获取到的请求的
    public JsonResponse<String> commonExceptionHandler(HttpServletRequest request,Exception e){
      String errorMsg = e.getMessage();
//      ConditionException区别RuntimeException，它有一个code字段
      if(e instanceof ConditionException){
           String errorCode = ((ConditionException)e).getCode();
           return new JsonResponse<>(errorCode,errorMsg);
      }else {
           return  new JsonResponse<>("500",errorMsg);
      }
  }
}
