package com.djl.bilibili.service;

import com.djl.bilibili.domain.auth.*;
import com.djl.bilibili.domain.constant.AuthRoleConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserAuthService {
    @Autowired
    private UserRoleService userRoleService;
    @Autowired
    private AuthRoleService authRoleService;
    //通过userId查询对于用户的权限
    public UserAuthorities getUserAuthorities(Long userId) {
        //通过userRoleService，用户和角色关联表根据userId查询到角色
        List<UserRole> userRoleList = userRoleService.getUserRoleByUserId(userId);
        //使用lambed表达式和stream流来操作userRoleList，得到角色的id集合
        Set<Long> roleIdSet = userRoleList.stream().map(UserRole::getRoleId).collect(Collectors.toSet());
        //再根据角色id，通过authRoleService来查询页面权限和资源权限
        List<AuthRoleElementOperation> roleElementOperationList = authRoleService.getRoleElementOperationsByRoleIds(roleIdSet);
        List<AuthRoleMenu> authRoleMenusList = authRoleService.getAuthRoleMenusByRoleIds(roleIdSet);
        //构建返回类型
        UserAuthorities userAuthorities = new UserAuthorities();
        userAuthorities.setRoleElementOperationList(roleElementOperationList);
        userAuthorities.setRoleMenuList(authRoleMenusList);
        return  userAuthorities;
    }

    public void addUserDefaultRole(Long id) {
        UserRole userRole = new UserRole();
        AuthRole role = authRoleService.getRoleByCode(AuthRoleConstant.ROLE_LV0);
        userRole.setUserId(id);
        userRole.setRoleId(role.getId());
        userRoleService.addUserRole(userRole);
    }
}
