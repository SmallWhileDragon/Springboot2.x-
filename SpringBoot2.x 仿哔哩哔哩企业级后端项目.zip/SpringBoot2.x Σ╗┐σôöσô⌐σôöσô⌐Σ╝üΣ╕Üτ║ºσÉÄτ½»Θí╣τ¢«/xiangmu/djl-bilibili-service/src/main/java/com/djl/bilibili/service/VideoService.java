package com.djl.bilibili.service;

import com.djl.bilibili.dao.VideoDao;
import com.djl.bilibili.domain.*;
import com.djl.bilibili.domain.exception.ConditionException;
import com.djl.bilibili.service.util.FastDFSUtil;
import com.djl.bilibili.service.util.ImageUtil;
import com.djl.bilibili.service.util.IpUtil;
import com.mysql.cj.x.protobuf.MysqlxCrud;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.FastByIDMap;
import org.apache.mahout.cf.taste.impl.model.GenericDataModel;
import org.apache.mahout.cf.taste.impl.model.GenericItemPreferenceArray;
import org.apache.mahout.cf.taste.impl.model.GenericPreference;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.UncenteredCosineSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.PreferenceArray;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.Java2DFrameConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import eu.bitwalker.useragentutils.UserAgent;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class VideoService {
    @Autowired
    private VideoDao videoDao;
    @Autowired
    private FastDFSUtil fastDFSUtil;
    @Autowired
    private UserCoinService userCoinService;
    @Autowired
    private UserService userService;
    @Autowired
    private ImageUtil imageUtil;
    @Autowired
    private FileService fileService;
    private static final  int FRAME_NO=16;
//    防止第一数据库操作成功，第二个失败，所以加一个回滚操作
    @Transactional
    public void addVideos(Video video) {
        Date now = new Date();
        video.setCreatTime(new Date());
        videoDao.addVideos(video);
       Long videoId = video.getId();
       List<VideoTag> tagList = video.getVideoTagList();
       //使用lamblt表达式赋值,利用取出的集合tagList字段对VideoTag.java实体类进行赋值
       tagList.forEach(item ->{
           item.setCreateTime(now);
           item.setVideoId(videoId);
       });
       videoDao.batchAddVideoTags(tagList);
    }

    public PageResult<Video> pageListVideos(Integer size, Integer no, String area) {
        //首先进行参数异常判断
        if(size == null||no==null){
            throw new ConditionException("参数异常！");
        }
        //使用Map<String,Object>类型进行封装数据
        Map<String,Object> params = new HashMap<>();
        //使用size,no，计算出两个分页参数start (no-1)*size)，limit size
        //并且使用Map集合将参数params.put("start",(no-1)*size)，params.put("limit",size)，params.put("area",area)存放其中
        params.put("start",(no-1)*size);
        params.put("limit",size);
        params.put("area",area);
        //新建一个list,用来存放视频
      List<Video> list = new ArrayList<>();
      //在数据库中根据Map<String,Object> params传输的start，limit参数进行数据库查询符合条件的video的数量total
      Integer total = videoDao.pageCountVideos(params);
      //然后进行total的判断，如果大于0，继续进行数据库查询，这次返回参数是list<>集合,里面存放的类是video
      if(total>0){
          list = videoDao.pageListVideos(params);
      }
      //最后将total和list分别作为键和值共同封装到PageResult<>(total,list)返回给前段
      return new PageResult<>(total,list);
    }

    public void viewVideoOnlineBySlice(HttpServletRequest request, HttpServletResponse response, String url) throws Exception {
        fastDFSUtil.viewVideoOnlineBySlice(request,response,url);
    }

    public void addVideoLike(Long videoId, Long userId) {
       Video video =  videoDao.getVideoById(videoId);
       if(video==null){
           throw new ConditionException("非法视频！");
       }
       VideoLike videoLike = videoDao.getVideoLikeByVideoIdAndUserId(videoId,userId);
       if(videoLike!=null){
           throw new ConditionException("已经点赞过!");
       }
       videoLike = new VideoLike();
       videoLike.setVideoId(videoId);
       videoLike.setUserId(userId);
       videoLike.setCreateTime(new Date());
       videoDao.addVideoLike(videoLike);
    }

    public void deleteVideoLike(Long videoId, Long userId) {
        videoDao.deleteVideoLike(videoId,userId);
    }

    public Map<String, Object> getVideoLikes(Long videoId, Long userId) {
         Long count = videoDao.getVideoLikes(videoId);
         VideoLike videoLike = videoDao.getVideoLikeByVideoIdAndUserId(videoId,userId);
         boolean like = videoLike!=null;
         Map<String,Object> result = new HashMap<>();
         result.put("count",count);
         result.put("like",like);
         return result;
    }
@Transactional
    public void addVideoCollection(VideoCollection videoCollection, Long userId) {
      Long videoId = videoCollection.getVideoId();
      Long groupId = videoCollection.getGroupId();
      if(videoId==null||groupId==null){
          throw new ConditionException("参数异常");
      }
      Video video = videoDao.getVideoById(videoId);
      if(video == null){
          throw new ConditionException("非法视频");
      }
      //删除原有的视频收藏
    videoDao.deleteVideoCollection(videoId,userId);
      //添加新的视频收藏
    videoCollection.setUserId(userId);
    videoCollection.setCreateTime(new Date());
    videoDao.addVideoCollection(videoCollection);

    }
    public void deleteVideoCollection(Long videoId, Long userId) {
        videoDao.deleteVideoCollection(videoId,userId);
    }
    public Map<String, Object> getVideoCollections(Long videoId, Long userId) {
        //判断收藏videoId的数量是否为0
        Long count = videoDao.getVideoCollections(videoId);
        //判断userId收藏videoId的数量是否为空
        VideoCollection videoCollection = videoDao.getVideoCollectionsByVideoIdAndUserId(videoId,userId);
        boolean like = videoCollection != null;
        //建立返回值的数据结构
        Map<String,Object> result = new HashMap<>();
        result.put("count",count);
        result.put("like",like);
        return result;
    }
@Transactional
    public void addVideoCoins(VideoCoin videoCoin, Long userId) {
        Long videoId = videoCoin.getVideoId();
        Integer amount = videoCoin.getAmount();
        if(videoId==null){
            throw new ConditionException("参数异常!");
        }
        Video video = videoDao.getVideoById(videoId);
        if(video==null){
            throw new ConditionException("非法视频!");
        }
        //查询当前登陆用户是否拥有足够的硬币
        Integer userCoinsAmount = userCoinService.getUserCoinsAmount(userId);
        userCoinsAmount = userCoinsAmount == null ? 0 : userCoinsAmount;
        if(amount > userCoinsAmount){
            throw new ConditionException("硬币数量不足");
        }
        //查询当前登陆用户对该视频已经投了多少硬币
        VideoCoin dbVideoCoin = videoDao.getVideoCoinByVideoIdAndUserId(videoId,userId);
        //新增视频投币
        if(dbVideoCoin==null){
            videoCoin.setUserId(userId);
            videoCoin.setCreateTime(new Date());
            videoDao.addVideoCoin(videoCoin);
        }else {
            Integer dbAmount = dbVideoCoin.getAmount();
            dbAmount+=amount;
            //更新视频投币
            videoCoin.setUserId(userId);
            videoCoin.setAmount(dbAmount);
            videoCoin.setUpdateTime(new Date());
            videoDao.updateVideoCoin(videoCoin);
        }
        //更新用户当前硬币总数
        userCoinService.updateUserCoinsAmount(userId,(userCoinsAmount-amount));
    }

    public Map<String, Object> getVideoCoins(Long videoId, Long userId) {
        Long count = videoDao.getVideoCoinsAmount(videoId);
        VideoCoin videoCollection = videoDao.getVideoCoinByVideoIdAndUserId(videoId,userId);
        boolean like = videoCollection != null;
        Map<String,Object> result = new HashMap<>();
        result.put("count",count);
        result.put("like",like);
        return result;
    }

    public void addVideoComment(VideoComment videoComment, Long userId) {
        Long videoId = videoComment.getVideoId();
        if(videoId==null){
            throw new ConditionException("参数异常！");
        }
        Video video = videoDao.getVideoById(videoId);
        if(video==null){
            throw new ConditionException("非法视频");
        }
        videoComment.setUserId(userId);
        videoComment.setCreateTime(new Date());
        videoDao.addVideoComment(videoComment);
    }

    public PageResult<VideoComment> pageListVideoComments(Integer size, Integer no, Long videoId) {
        Video video = videoDao.getVideoById(videoId);
        if (video == null) {
            throw new ConditionException("非法视频!");
        }
        Map<String, Object> params = new HashMap<>();
        params.put("start", (no - 1) * size);
        params.put("limit", size);
        params.put("videoId", videoId);
        Integer total = videoDao.pageCountVideoComments(params);
        List<VideoComment> list = new ArrayList<>();
        if (total > 0) {
            list = videoDao.pageListVideoComments(params);
            //根据rootId=null为条件，查询数据库VideoComment满足该条件的所以该视频评论的一级用户集合
            List<Long> parentIdList = list.stream().map(VideoComment::getId).collect(Collectors.toList());
            //根据一级用户id，rootId=一级用户id，批量查询二级评论用户集合
            List<VideoComment> childCommentList = videoDao.batchGetVideoCommentsByRootIds(parentIdList);
            //根据一级评论集合和二级评论集合通过stream流和lamble表达式list.stream().map(VideoComment::getUserId).collect(Collectors.toSet())
            // 过滤得到一级评论集合和二级评论集合的所有用户的id值
            Set<Long> userIdList = list.stream().map(VideoComment::getUserId).collect(Collectors.toSet());
            Set<Long> replyUserIdList = childCommentList.stream().map(VideoComment::getUserId).collect(Collectors.toSet());
            Set<Long> childUserIdList = childCommentList.stream().map(VideoComment::getReplyUserId).collect(Collectors.toSet());
            //将通过所有评论的id统一到一个列表中
            userIdList.addAll(replyUserIdList);
            userIdList.addAll(childUserIdList);
            //然后通过userService数据库表中的用户表根据id查询所有的用户信息
            List<UserInfo> userInfoList = userService.batchGetUserInfoByUserIds(userIdList);
            //吧查询到的所用用户集合List<UserInfo> userInfoList转换为Map<>类型进行存储，key为UserId value为用户信息UserInfo
            //这样做的好处在进行循环赋值的时候可以直接根据userId,得到得到对应的UserInfo
            Map<Long, UserInfo> userInfoMap = userInfoList.stream().collect(Collectors.toMap(UserInfo::getUserId, userInfo -> userInfo));
            //采用lamble表达式进行循环遍历，首先进行一级评论遍历
            list.forEach(comment -> {
                Long id = comment.getId();
                List<VideoComment> childList = new ArrayList<>();
                //二级评论遍历，进行一级id和二级rootId之间的equals比较
                childCommentList.forEach(child -> {
                    if (id.equals(child.getRootId())) {
                        child.setUserInfo(userInfoMap.get(child.getUserId()));
                        child.setReplyUserInfo(userInfoMap.get(child.getReplyUserId()));
                        childList.add(child);
                    }
                });
                comment.setChildList(childList);
                comment.setUserInfo(userInfoMap.get(comment.getUserId()));
            });
        }
        return new PageResult<>(total, list);
    }
    public Map<String, Object> getVideoDetails(Long videoId) {
        Video video = videoDao.getVideoDetails(videoId);
        Long userId = video.getUserId();
        User user = userService.getUserInfo(userId);
        UserInfo userInfo = user.getUserInfo();
        Map<String,Object> result = new HashMap<>();
        result.put("video",video);
        result.put("userInfo",userInfo);
        return result;
    }
    public void addVideoView(VideoView videoView, HttpServletRequest request) {
       Long userId = videoView.getUserId();
       Long videoId = videoView.getVideoId();
       //生成clientId
        String agent = request.getHeader("User-Agent");
       UserAgent userAgent  = UserAgent.parseUserAgentString(agent);
       String clientId = String.valueOf(userAgent.getId());
       String ip = IpUtil.getIP(request);
       Map<String,Object>  params = new HashMap<>();
       if(userId!=null){
           params.put("userId",userId);
       }else {
           params.put("ip",ip);
           params.put("clientId",clientId);
       }
       Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        params.put("today",sdf.format(now));
        params.put("videoId",videoId);
        //添加观看记录
        VideoView dbVideoView = videoDao.getVideoView(params);
        if(dbVideoView==null){
            videoView.setIp(ip);
            videoView.setClientId(clientId);
            videoView.setCreateTime(new Date());
            videoDao.addVideoView(videoView);
        }
    }

    public Integer getVideoViewCounts(Long videoId) {
        return videoDao.getVideoViewCounts(videoId);
    }

    /**
     * 基于用户的协同推荐
     * @param userId
     * @return
     */
    public List<Video> recommend(Long userId) throws TasteException {
      List<UserPreference> list = videoDao.getAlluserPreference();
      //创建数据模型
        DataModel dataModel = this.createDataModel(list);
        //获取用户相似程度,选用的是计算数据库中UncenteredCosineSimilarity这个方法，这个方法对于计算评分的数据模型是非常准确的
        UncenteredCosineSimilarity similarity = new UncenteredCosineSimilarity(dataModel);
        System.out.println(similarity.userSimilarity(11,12));
        //获取用户邻居
        UserNeighborhood userNeighborhood = new NearestNUserNeighborhood(2,similarity,dataModel);
        long[] ar = userNeighborhood.getUserNeighborhood(userId);
         //构建推荐器
        Recommender recommender = new GenericUserBasedRecommender(dataModel,userNeighborhood,similarity);
        //推荐视频
        List<RecommendedItem> recommendedItems = recommender.recommend(userId,5);
        List<Long> itemIds = recommendedItems.stream().map(RecommendedItem::getItemID).collect(Collectors.toList());
        return  videoDao.batchGetVideoByIds(itemIds);
    }
    private DataModel createDataModel(List<UserPreference> userPreferenceList){
        FastByIDMap<PreferenceArray> fastByIdMap = new FastByIDMap<>();
        Map<Long,List<UserPreference>> map = userPreferenceList.stream().collect(Collectors.groupingBy(UserPreference::getUserId));
        Collection<List<UserPreference>> list = map.values();
        for(List<UserPreference> userPreferences:list){
            GenericPreference[] array = new GenericPreference[userPreferences.size()];
            for(int i = 0;i<userPreferences.size();i++){
                UserPreference userPreference = userPreferences.get(i);
                GenericPreference item = new GenericPreference(userPreference.getUserId(), userPreference.getVideoId(), userPreference.getValue());
                array[i] = item;
            }
            fastByIdMap.put(array[0].getUserID(),new GenericItemPreferenceArray(Arrays.asList(array)));
        }
        return new GenericDataModel(fastByIdMap);
    }

    public List<VideoBinaryPicture> convertVideoToImage(Long videoId, String fileMd5)throws  Exception {
        com.djl.bilibili.domain.File file = fileService.getFileByMd5(fileMd5);
        String filePath = "/Users/hat/tmpfile/fileForVideoId" + videoId + "." + file.getType();
        //将单机dfs中的文件下载到本地
        fastDFSUtil.downLoadFile(file.getUrl(),filePath);
        FFmpegFrameGrabber fFmpegFrameGrabber = FFmpegFrameGrabber.createDefault(filePath);
        fFmpegFrameGrabber.start();
        //  获取视频总的帧数
        int ffLength = fFmpegFrameGrabber.getLengthInFrames();
        //每一帧可以用frame进行表示,frame表示帧的变量
        Frame frame;
        //通过Java2DFrameConverter将帧转换成文件VideoBinaryPicture
        Java2DFrameConverter converter = new Java2DFrameConverter();
        int count = 1;
        //List<VideoBinaryPicture> pictures是返回的结果的集合
        List<VideoBinaryPicture> pictures = new ArrayList<>();
        for(int i = 1; i< ffLength;i++){
            //在遍历的时候获取这个视频每一帧的时间戳,运用javacv提供的getTimestamp方法
            long timestamp = fFmpegFrameGrabber.getTimestamp();
            //运用javacv提供的grabImage法，截取每一帧图片，并赋值给frame
            frame = fFmpegFrameGrabber.grabImage();
            if(count==i){
                if(frame==null){
                    throw new ConditionException("无效帧");
                }
                //利用converter.getBufferedImage(frame)将其转换为类似与图片的格式bufferedImage
                BufferedImage bufferedImage = converter.getBufferedImage(frame);
                //建立一个ByteArrayOutputStream输出流
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                //将bufferedImage文件写入到本地，格式为png
                ImageIO.write(bufferedImage,"png",os);
                InputStream inputStream = new ByteArrayInputStream(os.toByteArray());
                //输出黑白剪影文件、
                //制造一个临时文件
                java.io.File outputFile = java.io.File.createTempFile("covert-" + videoId + "-",".png");
                //下面两行的意思是将调用百度api获得的黑白剪影文件写入临时文件中
                BufferedImage binaryImg = imageUtil.getBodyOutline(bufferedImage,inputStream);
               ImageIO.write(binaryImg,"png",outputFile);
               //有的浏览器或网站需要吧图片白色的部分转化为透明色，使用以下方法可以实现
                imageUtil.transferAlpha(outputFile,outputFile);
                //上传视频剪影文件
                String imgUrl = fastDFSUtil.uploadCommonFile(outputFile,"png");
               VideoBinaryPicture videoBinaryPicture = new VideoBinaryPicture();
               videoBinaryPicture.setFrameNo(i);
               videoBinaryPicture.setUrl(imgUrl);
               videoBinaryPicture.setVideoId(videoId);
               videoBinaryPicture.setVideoTimestamp(timestamp);
               pictures.add(videoBinaryPicture);
               count+=FRAME_NO;
               //删除临时文件
                outputFile.delete();
            }
        }
        //删除临时本地文件
        java.io.File tmpFile = new java.io.File(filePath);
        tmpFile.delete();
        //批量添加视频剪影文件
        videoDao.batchAddVideoBinaryPictures(pictures);
        return pictures;
    }
    public List<VideoTag> getVideoTagsByVideoId(Long videoId){
        return videoDao.getVideoTagsByVideoId(videoId);
    }
    public void deleteVideoTags(List<Long> tagIdList, Long videoId){
        videoDao.deleteVideoTags(tagIdList,videoId);
    }
    public List<VideoBinaryPicture> getVideoBinaryImages(Map<String,Object> params){
        return videoDao.getVideoBinaryImages(params);
    }
}
