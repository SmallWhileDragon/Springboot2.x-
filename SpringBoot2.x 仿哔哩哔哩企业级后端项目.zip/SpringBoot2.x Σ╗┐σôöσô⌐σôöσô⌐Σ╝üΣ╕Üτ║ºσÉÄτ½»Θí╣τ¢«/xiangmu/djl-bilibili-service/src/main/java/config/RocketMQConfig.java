package config;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.djl.bilibili.domain.UserFollowing;
import com.djl.bilibili.domain.UserMoment;
import com.djl.bilibili.domain.constant.UserMomentsConstant;
import com.djl.bilibili.service.UserFollowingService;
import com.djl.bilibili.service.websocket.WebsocketService;
import io.netty.util.internal.StringUtil;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListener;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.common.message.MessageExt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//@Configuration
public class RocketMQConfig {
    //在该配置类中@Value("${rocketmq.name.server.address}")
    ////RocketMQConfig名称服务器地址,${rocketmq.name.server.address}配置在application-test-properties文件当中
    //rocketmq.name.server.address=127.0.0.1:9876
    @Value("${rocketmq.name.server.address}")
    private String nameServerADdr;
    //@Autowired依赖引入redis工具类RedisTemplate
    //@Autowired依赖引入UserFollowingService，因为推送是推送用户关注的人发的消息
    @Autowired
    private RedisTemplate<String,String> redisTemplate;
    @Autowired
    private UserFollowingService userFollowingService;
//    建立一个生产者与消费者模式
    //新建一个消息的生产者，为了实现用户动态提醒，所以需要将生产者和消费者和用户动态进行一个同一的命名
    @Bean("momentsProducer")
    //DefaultMQProducer是rocketmq原生的实体类
public DefaultMQProducer momentsProducer() throws Exception{
        //因为DefaultMQProducer需要有一个参数是生产者的分组，因此我们在常量类中建立public static生产者分组常量
        DefaultMQProducer producer = new DefaultMQProducer(UserMomentsConstant.GROUP_MOMENTS);
        //set生产者的地址
        producer.setNamesrvAddr(nameServerADdr);
        //启动生产者
        producer.start();
        return producer;
    }
    //新建一个消费者,使用DefaultMQPushConsumer，也就是订阅发布模式的第一种方式push推送的方式
    @Bean("momentsConsumer")
    public DefaultMQPushConsumer momentsConsumer() throws Exception{
        //同生产者一样，新建一个常量作为消费者的分组，通过new DefaultMQPushConsumer获取消费者实体类
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(UserMomentsConstant.GROUP_MOMENTS);
        //set消费者的地址
        consumer.setNamesrvAddr(nameServerADdr);
        //在UserMomentsConstant常量类中写一个常量订阅一级主题TOPIC_MOMENTS，二级主题"*"
        consumer.subscribe(UserMomentsConstant.TOPIC_MOMENTS,"*");
//        需要通过消费者注册一个监听器来俘获代理人发出的请求，重写监听器的逻辑代码
        consumer.registerMessageListener(new MessageListenerConcurrently() {
            @Override
            public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
                //列表只有一个元素，所以取出列表中的第一个元素
                MessageExt msg = msgs.get(0);
                if(msg==null){
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }
//                 取出msg.getBody()，并将其转化为String类型的字符串
                String bodyStr = new String(msg.getBody());
                //将bodyStr转化为对应的UserMoment实体类，这个实体类主要有主键id,用户userId,以及内容详细等字段,使用JSONObject.toJavaObject方法，
                // 将其转化为一个UserMoment实体类，因此JSONObject是一个map类型所以转化的第一个参数是转化的内容，第二个参数转化的类型
                UserMoment userMoment = JSONObject.toJavaObject(JSONObject.parseObject(bodyStr),UserMoment.class);
                //获取实体类对应的userId，这个时候我们可以引入之前写的用户关注（UserFollowingService）逻辑，获取userId对应的粉丝
                Long userId = userMoment.getUserId();
                //通过userFollowingService.getUserFans(userId)获取粉丝列表
               List<UserFollowing> fanList =  userFollowingService.getUserFans(userId);
               //对每个粉丝进行遍历,使用push的方式吧消息发送到每个粉丝，因此我们要先吧消息发送到redis当中，然后用户通过redis区查询，这样效率更高，所以我们要引入redis
               for(UserFollowing fan: fanList){
                   //根据fan.getUserId作为key值
                   String key = "subscribed-" + fan.getUserId();
                   //然后检查 通过redisTemplate.opsForValue().get(key)能不能查询到
                   String subscribedListStr = redisTemplate.opsForValue().get(key);
                   //由于粉丝不止关注一个up主，所以查询到的应该是一个列表，但是redis查询的结果是一个String，所以要将String转换为List
                   List<UserMoment> subscribedList;
                   if(StringUtil.isNullOrEmpty(subscribedListStr)){
                       subscribedList = new ArrayList<>();
                   }else {
                       //使用JSONArray.parseArray可以将字符串转化为列表
                       subscribedList = JSONArray.parseArray(subscribedListStr,UserMoment.class);
                   }
                   //将消息添加到subscribedList中
                   subscribedList.add(userMoment);
                   //将subscribedList在转化为String类型存入redis当中
                   redisTemplate.opsForValue().set(key,JSONObject.toJSONString(subscribedList));

               }
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
        } );
        consumer.start();
        return consumer;
    }
    @Bean("danmusProducer")
    public DefaultMQProducer defaultMQProducer() throws  Exception{
        //实例化消费者生产者Producer
        DefaultMQProducer producer = new DefaultMQProducer(UserMomentsConstant.GROUP_DANMUS);
        //设置NameServer的地址
        producer.setNamesrvAddr(nameServerADdr);
        //启动Producer实例
        producer.start();
        return producer;
    }
    @Bean("danmusConsumer")
    public DefaultMQPushConsumer danmusConsumer() throws Exception{
        //实例化消费者
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(UserMomentsConstant.GROUP_DANMUS);
        //设置NamServer地址
        consumer.setNamesrvAddr(nameServerADdr);
        //订阅一个或者多个Topic,以及Tag来过滤需要消费的消息
        consumer.subscribe(UserMomentsConstant.TOPIC_DANMUS,"*");
        //注册监听器处理从broker拉取回来的消息
        consumer.registerMessageListener(new MessageListenerConcurrently() {
            @Override
            public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext consumeConcurrentlyContext) {
                //列表只有一个元素，所以取出列表中的第一个元素
               MessageExt msg = msgs.get(0);
               //取出msg.getBody()，并将其转化为String类型的字符串
               byte[] msgByte = msg.getBody();
               String bodyStr = new String(msgByte);
               //JSONObject是一个map类型
               JSONObject jsonObject = JSONObject.parseObject(bodyStr);
               String sessionId  = jsonObject.getString("sessionId");
               String message = jsonObject.getString("message");
                WebsocketService  websocketService = WebsocketService.WEBSOCKET_MAP.get(sessionId);
                if(websocketService.getSession().isOpen()){
                    try {
                        websocketService.sendMessage(message);
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }
                //标记消息已经成功被消费
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
        });
                //标记该消息已经被成功消费
        consumer.start();
        return consumer;
    }

}
