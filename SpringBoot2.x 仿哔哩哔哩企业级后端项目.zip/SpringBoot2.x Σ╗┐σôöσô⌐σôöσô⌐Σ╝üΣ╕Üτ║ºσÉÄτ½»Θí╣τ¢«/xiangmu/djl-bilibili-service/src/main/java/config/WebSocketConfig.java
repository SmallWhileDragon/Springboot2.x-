package config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

@Configuration
public class WebSocketConfig {
    @Bean
    //ServerEndpointExporter主要是websocket发现和导出服务器的端点，这个配置是我们使用websocket的一个必要条件，因此
    //我们要将ServerEndpointExporter进行一个bean注入
    public ServerEndpointExporter serverEndpointExporter(){
        return new ServerEndpointExporter();
    }
}
