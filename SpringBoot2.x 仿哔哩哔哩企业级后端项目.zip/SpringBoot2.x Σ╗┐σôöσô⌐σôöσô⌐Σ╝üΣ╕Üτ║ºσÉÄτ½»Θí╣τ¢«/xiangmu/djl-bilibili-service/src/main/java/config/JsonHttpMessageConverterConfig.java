package config;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class JsonHttpMessageConverterConfig {

     @Bean
    @Primary
    public HttpMessageConverters fastJsonHttpMessageConvertes(){
         FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
         //FastJsonConfig配置相关的类
         FastJsonConfig fastJsonConfig = new FastJsonConfig();
         //配置时间格式
         fastJsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");
         //对JSON数据序列化的配置
         fastJsonConfig.setSerializerFeatures(
                 //JSON格式化输出
                 SerializerFeature.PrettyFormat,
                 //value为null的转换为空字符串
                 SerializerFeature.WriteNullStringAsEmpty,
                 SerializerFeature.WriteNullListAsEmpty,
                 SerializerFeature.WriteMapNullValue,
                 //升序排序
                 SerializerFeature.MapSortField,
//                 关闭循环引用,防止打印出相同value的地址
                 SerializerFeature.DisableCircularReferenceDetect
         );
         fastConverter.setFastJsonConfig(fastJsonConfig);
         return new HttpMessageConverters(fastConverter);
     }
}
