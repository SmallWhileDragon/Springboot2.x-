package com.djl.bilibili.api;

import com.djl.bilibili.api.support.UserSupport;
import com.djl.bilibili.domain.JsonResponse;
import com.djl.bilibili.domain.auth.UserAuthorities;
import com.djl.bilibili.service.UserAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserAuthApi {
    @Autowired
    private UserSupport userSupport;
    @Autowired
    private UserAuthService userAuthService;
//    通过userId找到用户对应的角色，再找到角色对应角色和页面以及角色和元素的关系的集合
    @GetMapping("/user-authorities")
    public JsonResponse<UserAuthorities> getUserAuthorities(){
        Long userId = userSupport.getCurrentUserId();
        UserAuthorities userAuthorities = userAuthService.getUserAuthorities(userId);
        return new JsonResponse<>(userAuthorities);
    }

}
