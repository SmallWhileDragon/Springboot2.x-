package com.djl.bilibili.api;

import com.djl.bilibili.domain.JsonResponse;
import com.djl.bilibili.domain.Video;
import com.djl.bilibili.service.DemoService;
import com.djl.bilibili.service.ElasticSearchService;
import com.djl.bilibili.service.util.FastDFSUtil;
import org.elasticsearch.common.recycler.Recycler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
public class DemoApi {
    @Autowired
    private DemoService demoService;
    @Autowired
    private FastDFSUtil fastDFSUtil;
    @Autowired
    private ElasticSearchService elasticSearchService;
    @GetMapping("/query")
    public Long query(Long id){
        return demoService.query(id);
    }
    @GetMapping("/slices")
    public void slices(MultipartFile file)throws Exception{
          fastDFSUtil.convertFileToSlices(file);
    }
    @GetMapping("/es-videos")
    public JsonResponse<Video> getEsVideos(@RequestParam String keyword){
       Video video = elasticSearchService.getVideo(keyword);
       return new JsonResponse<>(video);
    }
}
