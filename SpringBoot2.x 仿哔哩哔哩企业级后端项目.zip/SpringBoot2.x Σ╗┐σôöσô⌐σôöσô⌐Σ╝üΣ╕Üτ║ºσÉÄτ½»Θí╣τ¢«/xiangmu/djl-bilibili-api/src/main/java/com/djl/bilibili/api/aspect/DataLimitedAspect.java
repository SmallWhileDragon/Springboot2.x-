package com.djl.bilibili.api.aspect;

import com.djl.bilibili.api.support.UserSupport;
import com.djl.bilibili.domain.UserMoment;
import com.djl.bilibili.domain.annotation.ApiLimitedRole;
import com.djl.bilibili.domain.auth.UserRole;
import com.djl.bilibili.domain.constant.AuthRoleConstant;
import com.djl.bilibili.domain.exception.ConditionException;
import com.djl.bilibili.service.UserRoleService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Order(1)
@Component
@Aspect
public class DataLimitedAspect {
    @Autowired
    private UserSupport userSupport;
    @Autowired
    private UserRoleService userRoleService;
//    写入相关切点
    @Pointcut("@annotation(com.djl.bilibili.domain.annotation.DataLimited)")
    public void check(){
    }
    @Before("check()")
    public void doBefore(JoinPoint jointPoint){
        Long userId = userSupport.getCurrentUserId();
        List<UserRole> userRoleList = userRoleService.getUserRoleByUserId(userId);
//java8的stream流
        Set<String> roleCodeSet = userRoleList.stream().map(UserRole::getRoleCode).collect(Collectors.toSet());
//使用连接点给的方法jointPoint.getArgs()这个方法会将我们切到的参数的方法的返回参数获取到
        Object[] args = jointPoint.getArgs();
        for(Object arg: args){
            if(arg instanceof UserMoment){
                UserMoment userMoment = (UserMoment)arg;
                String type = userMoment.getType();
                if(roleCodeSet.contains(AuthRoleConstant.ROLE_LV0)&&!"0".equals(type)){
                    throw new ConditionException("参数异常");
                }else if(roleCodeSet.contains(AuthRoleConstant.ROLE_LV1)&&(!"0".equals(type)||!"1".equals(type))){
                    throw new ConditionException("参数异常");
                }
            }
        }

    }

}
