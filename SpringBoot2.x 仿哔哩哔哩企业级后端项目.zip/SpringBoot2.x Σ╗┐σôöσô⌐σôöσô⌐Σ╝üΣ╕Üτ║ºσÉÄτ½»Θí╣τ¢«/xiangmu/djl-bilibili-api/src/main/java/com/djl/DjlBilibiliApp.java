package com.djl;

import com.djl.bilibili.service.websocket.WebsocketService;
import org.apache.catalina.core.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableTransactionManagement
@EnableAsync
@EnableScheduling
public class DjlBilibiliApp {
    public static void main(String[] args){
       ConfigurableApplicationContext app =  SpringApplication.run(DjlBilibiliApp.class,args);
        WebsocketService.setApplicationContext(app);
    }
}
