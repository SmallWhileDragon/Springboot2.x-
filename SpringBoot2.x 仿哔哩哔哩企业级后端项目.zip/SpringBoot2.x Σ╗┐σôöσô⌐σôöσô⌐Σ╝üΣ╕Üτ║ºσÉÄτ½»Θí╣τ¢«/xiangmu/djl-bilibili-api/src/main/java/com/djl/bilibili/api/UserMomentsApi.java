package com.djl.bilibili.api;

import com.djl.bilibili.api.support.UserSupport;
import com.djl.bilibili.domain.JsonResponse;
import com.djl.bilibili.domain.UserMoment;
import com.djl.bilibili.domain.annotation.ApiLimitedRole;
import com.djl.bilibili.domain.annotation.DataLimited;
import com.djl.bilibili.domain.constant.AuthRoleConstant;
import com.djl.bilibili.service.UserMomentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserMomentsApi {
    @Autowired
    private UserMomentsService userMomentService;
    @Autowired
    private UserSupport userSupport;
    @ApiLimitedRole(limitedRoleCodeList = {AuthRoleConstant.ROLE_LV0})
    @DataLimited
    //添加用户消息，并将消息发送到粉丝
    @PostMapping("/user-moments")
    public JsonResponse<String> addUserMoments(@RequestBody UserMoment userMoment)throws Exception{
        Long userId = userSupport.getCurrentUserId();
        userMoment.setUserId(userId);
        userMomentService.addUserMoments(userMoment);
        return JsonResponse.success();
    }
    //粉丝查询订阅动态
    @GetMapping("/user-subscribed-moments")
    public JsonResponse<List<UserMoment>> getUserSubscribedMoments(){
        Long userId = userSupport.getCurrentUserId();
        List<UserMoment> list = userMomentService.getUserSubscribedMoments(userId);
        return new JsonResponse<>(list);
    }
}
