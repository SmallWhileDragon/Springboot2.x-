package com.djl.bilibili.api;

import com.alibaba.fastjson.JSONObject;
import com.djl.bilibili.api.support.UserSupport;
import com.djl.bilibili.domain.JsonResponse;
import com.djl.bilibili.domain.PageResult;
import com.djl.bilibili.domain.User;
import com.djl.bilibili.domain.UserInfo;
import com.djl.bilibili.service.UserFollowingService;
import com.djl.bilibili.service.UserService;
import com.djl.bilibili.service.util.RSAUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.print.attribute.standard.PageRanges;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
public class UserApi {
    @Autowired
    private UserService userService;
    @Autowired
    private UserSupport userSupport;
    @Autowired
    private UserFollowingService userFollowingService;
    @GetMapping("/users")
    public JsonResponse<User> getuserInfo(){
        Long userId = userSupport.getCurrentUserId();
        User user = userService.getUserInfo(userId);
        return new JsonResponse<>(user);
    }
//    获取公钥
    @GetMapping("/rsa-pks")
    public JsonResponse<String> getREaPublicKey(){
        String pk = RSAUtil.getPublicKeyStr();
        return  new JsonResponse<>(pk);
    }
//    获取用户注册
    @PostMapping("/users")
    public JsonResponse<String> addUser(@RequestBody User user){
        userService.addUser(user);
        return  JsonResponse.success();
    }
//    获取用户登陆
    @PostMapping("/user-tokens")
    public JsonResponse<String> login(@RequestBody User user)throws Exception{
        String token = userService.login(user);
        return new JsonResponse<>(token);
    }
//    实现总用户账户的更新功能
    @PutMapping("/users")
    public JsonResponse<String> updateUsers(@RequestBody User user)throws  Exception{
           userService.updateUsers(user);
           return JsonResponse.success();
    }
//    实现用户更新
    @PutMapping("/user-infos")
    public JsonResponse<String> updateUserInfos(@RequestBody UserInfo userInfo){
        Long userId = userSupport.getCurrentUserId();
        userInfo.setUserId(userId);
        userService.updateUserInfos(userInfo);
        return JsonResponse.success();
    }
//    分页查询用户列表
    @GetMapping("/user-infos")
    public JsonResponse<PageResult<UserInfo>> PageListUserInfos(@RequestParam Integer no,@RequestParam Integer size,String nick){
      Long userId = userSupport.getCurrentUserId();
//      JSONObject底层是一个map的数据结构,JSONObject使用更加方便，在获取数据时不需要作类型转换
        JSONObject params = new JSONObject();
        params.put("no",no);
        params.put("size",size);
        params.put("nick",nick);
        params.put("userId",userId);
        PageResult<UserInfo> result  = userService.pageListUserInfos(params);
        //判断查询的用户，是否已经被关注了，没有被关注的才可以被关注
        if(result.getTotal()>0){
              List<UserInfo> checkedUserInfoList =  userFollowingService.checkFollowingStatus(result.getList(), userId);
              result.setList(checkedUserInfoList);
        }
        return  new JsonResponse<>(result);
    }
//    使用双token机制
    @PostMapping("/user-dts")
    public JsonResponse<Map<String,Object>> loginForDts(@RequestBody User user)throws  Exception{
       Map<String,Object> map = userService.loginForDts(user);
       return new JsonResponse<>(map);
    }
//    用户退出登陆接口
    @DeleteMapping("/refresh-tokens")
    public JsonResponse<String> logout(HttpServletRequest request){
      String refreshToken = request.getHeader("refreshToken");
      Long userId = userSupport.getCurrentUserId();
      userService.logout(refreshToken,userId);
      return JsonResponse.success();
    }
//    刷新用户token
    @PostMapping("/access-tokens")
    public JsonResponse<String> refreshAccessToken(HttpServletRequest request) throws Exception{
       String refreshToken = request.getHeader("refreshToken");
       String accessToken = userService.refreshAccessToken(refreshToken);
       return new JsonResponse<>(accessToken);
    }
}
