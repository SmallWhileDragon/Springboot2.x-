package com.djl.bilibili.api.aspect;

import com.djl.bilibili.api.support.UserSupport;
import com.djl.bilibili.domain.annotation.ApiLimitedRole;
import com.djl.bilibili.domain.auth.UserRole;
import com.djl.bilibili.domain.exception.ConditionException;
import com.djl.bilibili.service.UserRoleService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Order(1)
//Component主要标注在配置类，工具类
@Component
//表明这个class是一个切面class
@Aspect
public class ApiLimitedRoleAspect {
    @Autowired
    private UserSupport userSupport;
    @Autowired
    private UserRoleService userRoleService;
//    写入相关切点
    @Pointcut("@annotation(com.djl.bilibili.domain.annotation.ApiLimitedRole)")
    public void check(){
    }
    //@annotation(apiLimitedRole)在给角色编码列表传值的时候，通常会传入哪些角色针对api接口的调用被限制
    @Before("check() && @annotation(apiLimitedRole)")
    public void doBefore(JoinPoint jointPoint, ApiLimitedRole apiLimitedRole){
        //通过userId获取在userRoleService中获取userRoleList
        Long userId = userSupport.getCurrentUserId();
        List<UserRole> userRoleList = userRoleService.getUserRoleByUserId(userId);
        //通过apiLimitedRole.limitedRoleCodeList先获取哪些角色针对api接口的调用被限制的列表
        String[] limitedRoleCodeList = apiLimitedRole.limitedRoleCodeList();
        //java8的stream流，吧里面列表满足的元素数组转换为set类型，方便取出比较
        Set<String> limitedRoleCodeSet = Arrays.stream(limitedRoleCodeList).collect(Collectors.toSet());
        //使用java8的stream流映射出getRoleCode
        Set<String> roleCodeSet = userRoleList.stream().map(UserRole::getRoleCode).collect(Collectors.toSet());
        // retainAll方法可以用来取出两个集合的交集
        roleCodeSet.retainAll(limitedRoleCodeSet);
        if(roleCodeSet.size()>0){
            throw new ConditionException("权限不足！");
        }
    }

}
