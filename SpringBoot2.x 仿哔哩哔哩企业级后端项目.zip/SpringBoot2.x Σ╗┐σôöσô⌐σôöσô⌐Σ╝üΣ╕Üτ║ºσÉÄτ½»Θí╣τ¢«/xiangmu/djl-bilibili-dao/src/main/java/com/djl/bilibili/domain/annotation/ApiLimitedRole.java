package com.djl.bilibili.domain.annotation;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;
//RetentionPolicy.RUNTIME表明该注解在运行阶段进行执行
@Retention(RetentionPolicy.RUNTIME)
//意思是可以在方法中进行注解
@Target({ElementType.METHOD})
@Documented
@Component
public @interface ApiLimitedRole {
 //角色编码列表
 String[] limitedRoleCodeList() default {};
}
