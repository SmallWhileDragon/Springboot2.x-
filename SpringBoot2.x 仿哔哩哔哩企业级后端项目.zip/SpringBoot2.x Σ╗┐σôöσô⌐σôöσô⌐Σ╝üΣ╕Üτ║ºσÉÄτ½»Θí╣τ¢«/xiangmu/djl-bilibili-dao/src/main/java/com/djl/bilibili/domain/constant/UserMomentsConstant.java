package com.djl.bilibili.domain.constant;

public interface UserMomentsConstant {
    public static final String GROUP_MOMENTS = "MomentsGroup";
    public static  final String TOPIC_MOMENTS = "TopicMoments";
    public static  final String GROUP_DANMUS = "DanmusGroup";
    public static  final String TOPIC_DANMUS = "Topic-Danmus";

}
