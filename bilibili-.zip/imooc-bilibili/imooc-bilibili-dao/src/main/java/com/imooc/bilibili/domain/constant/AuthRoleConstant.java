package com.imooc.bilibili.domain.constant;

public interface AuthRoleConstant {

    public static final String ROLE_LV0 = "Lv0";

    public static final String ROLE_LV1 = "Lv1";
}
